document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("filterBtn");

  btn.addEventListener("click", () => {
    const input = document.getElementById('keywords').value;
    const keywords = input.split('\n').map(k => k.trim()).filter(k => k.length > 0);

    chrome.tabs.create({
      url: chrome.runtime.getURL('pdfjs/viewer.html')
    }, (tab) => {
      setTimeout(() => {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          args: [keywords],
          func: (keywords) => {
            window.postMessage({ keywords}, '*');
          }
        });
      }, 1000);
    });
  });
});
