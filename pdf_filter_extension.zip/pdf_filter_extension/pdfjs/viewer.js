pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.js';

let canvases = [];
let pageTexts = [];

function loadPDF(fileUrl) {
  const loadingTask = pdfjsLib.getDocument(fileUrl);
  loadingTask.promise.then(pdf => {
    canvases = [];
    pageTexts = [];
    const container = document.getElementById('canvas-container');
    container.innerHTML = '';  // clear previous canvases

    for (let i = 1; i <= pdf.numPages; i++) {
      pdf.getPage(i).then(page => {
        const scale = 1.5;
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement('canvas');
        canvas.style.margin = "10px";
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        container.appendChild(canvas);
        page.render({ canvasContext: context, viewport }).promise.then(() => {
          page.getTextContent().then(text => {
            const pageText = text.items.map(item => item.str).join(" ");
            pageTexts[i - 1] = pageText.toLowerCase();
            canvases[i - 1] = canvas;
          });
        });
      });
    }
  });
}

function filterCanvases(keywords) {
  if (!keywords || keywords.length === 0) {
    canvases.forEach(c => c.style.display = ''); // show all
    return;
  }
  canvases.forEach((canvas, idx) => {
    const text = pageTexts[idx] || '';
    const hasKeyword = keywords.some(k => text.includes(k.toLowerCase()));
    canvas.style.display = hasKeyword ? '' : 'none';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('pdf-upload').addEventListener('change', e => {
    const file = e.target.files[0];
    if (file) {
      const fileURL = URL.createObjectURL(file);
      loadPDF(fileURL);
    }
  });

  document.getElementById('filter-btn').addEventListener('click', () => {
    const input = document.getElementById('keyword-input').value;
    const keywords = input.split(',').map(k => k.trim()).filter(k => k.length > 0);
    filterCanvases(keywords);
  });
});
